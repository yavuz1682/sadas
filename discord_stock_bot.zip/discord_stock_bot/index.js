const fs = require('fs');
const { Client, GatewayIntentBits } = require('discord.js');
const config = require('./config.json');
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });

client.commands = new Map();
const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));
for (const file of commandFiles) {
    const command = require(`./commands/${file}`);
    client.commands.set(command.name, command);
}

client.on('messageCreate', async message => {
    if (message.author.bot) return;

    // Selam cevapları
    if (['sa', 'as'].includes(message.content.toLowerCase())) {
        return message.reply('Aleyküm selam, hoş geldin!');
    }

    // Prefixli komutlar
    if (!message.content.startsWith(config.prefix)) return;
    const args = message.content.slice(config.prefix.length).trim().split(/ +/);
    const cmd = args.shift().toLowerCase();

    if (client.commands.has(cmd)) {
        try {
            client.commands.get(cmd).execute(message, args);
        } catch (error) {
            console.error(error);
            message.reply('Komutu çalıştırırken bir hata oluştu.');
        }
    }
});

client.once('ready', () => {
    console.log(`Bot aktif: ${client.user.tag}`);
});

client.login(config.token);
