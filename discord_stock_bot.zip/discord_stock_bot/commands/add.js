const fs = require('fs');
const path = './depo';

module.exports = {
    name: 'add',
    execute(message, args) {
        if (!message.member.permissions.has('Administrator')) return message.reply('Sadece adminler ekleyebilir.');
        if (args.length < 2) return message.reply('Kullanım: !add <kategori> <veri>');

        const kategori = args[0].toLowerCase();
        const veri = args.slice(1).join(' ');

        fs.appendFileSync(`${path}/${kategori}.txt`, veri + '\n');
        message.reply(`${kategori} stoğuna eklendi.`);
    }
}
