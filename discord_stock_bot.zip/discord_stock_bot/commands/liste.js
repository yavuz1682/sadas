const fs = require('fs');
const path = './depo';

module.exports = {
    name: 'liste',
    execute(message) {
        let result = '';
        const files = fs.readdirSync(path);
        for (const file of files) {
            const content = fs.readFileSync(`${path}/${file}`, 'utf-8');
            const count = content.trim().split('\n').filter(x => x).length;
            result += `${file.replace('.txt','')}: ${count} adet\n`;
        }
        message.channel.send(result || 'Stokta hiçbir şey yok.');
    }
}
