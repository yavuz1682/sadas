module.exports = {
    name: 'sunucu',
    execute(message) {
        const { guild } = message;
        message.channel.send(`Sunucu adı: ${guild.name}\nÜye sayısı: ${guild.memberCount}`);
    }
}
