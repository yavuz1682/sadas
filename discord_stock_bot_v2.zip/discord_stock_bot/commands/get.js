const fs = require('fs');
const path = './depo';
const cooldown = new Map(); // kullanıcı ID -> timestamp

module.exports = {
    name: 'get',
    async execute(message, args) {
        if (args.length < 1) return message.reply('Kullanım: !get <kategori>');

        const kategori = args[0].toLowerCase();
        const dosya = `${path}/${kategori}.txt`;

        if (!fs.existsSync(dosya)) return message.reply('Bu kategoride veri bulunamadı.');

        const now = Date.now();
        const cooldownTime = 30 * 60 * 1000; // 30 dakika

        if (cooldown.has(message.author.id)) {
            const expiration = cooldown.get(message.author.id) + cooldownTime;
            if (now < expiration) {
                const kalan = Math.ceil((expiration - now) / 60000);
                return message.reply(`Bu komutu tekrar kullanmak için ${kalan} dakika beklemelisin.`);
            }
        }

        let lines = fs.readFileSync(dosya, 'utf-8').split('\n').filter(Boolean);
        if (lines.length === 0) return message.reply('Stokta kalmamış.');

        const hesap = lines.shift();
        fs.writeFileSync(dosya, lines.join('\n'));

        cooldown.set(message.author.id, now);

        try {
            await message.author.send(`İstediğin ${kategori} hesabın: ${hesap}`);
            message.reply('Hesabın özel mesajla gönderildi.');
        } catch {
            message.reply('Özel mesajın kapalı, hesabı gönderemedim.');
        }
    }
}
